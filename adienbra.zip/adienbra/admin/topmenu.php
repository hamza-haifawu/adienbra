<!-- creating headin of dashboard -->
<div class=" py-3 text-white" style="background-color: teal">
      <h1>&nbsp;&nbsp;<i class="fas fa-chart-bar"></i> Dashboard</h1>
    </div>
    <div class="bg-light p-3">
     
    <div class="row">
       <div class="col-md-4">
         <a href="addstudent.php" class="btn btn-primary d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp;ADD STUDENT</a>
       </div>
       <div class="col-md-4">
         <a href="addstaff.php" class="btn btn-success d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp; ADD Staff</a>
       </div>
       <div class="col-md-4">
         <a href="" class="btn btn-warning d-block font-weight-bold">
          <i class="fas fa-plus"></i> &nbsp; Attendance</a>
       </div>
    </div>
  </div>
  <!-- dashboard heading ends -->