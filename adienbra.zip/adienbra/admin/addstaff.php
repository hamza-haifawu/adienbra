<?php
// Include config file
session_start();
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = $confirm_password = $firstname = $lastname = $staffclass = $phonenumber = "";
$username_err = $password_err = $confirm_password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate username
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter a username.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM staff WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            $param_firstname = trim($_POST["firstname"]);
            $param_lastname = trim($_POST["username"]);
            $param_staffclass = trim($_POST["staffclass"]);
            $param_phonenumber = trim($_POST["phonenumber"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have atleast 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO staff (firstname, lastname, staffclass, phonenumber, username, password) 
        VALUES (?,?,?,?,?,?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssssss",$param_firstname,$param_firstname, $param_staffclass,
            $param_phonenumber, $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                $_SESSION['msg'] = "Staff Member Added succesfully...";
                $_SESSION['alert'] = "alert alert-warning"; 
                header("location: welcome.php");
            } else{
                $_SESSION['msg'] = "Something went wrong. Please try again later.";
                $_SESSION['alert'] = "alert alert-warning"; 
                header("location: welcome.php");
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($link);
}
?>
 

<?php require('head.php');?>
  <!-- Start your project here-->
  <?php require('navmenu.php');?>
  <?php require('topmenu.php');?>
  <!-- dashboaRd contet start -->
  <div class="container-fluid">
    
  <?php if(isset($_SESSION['msg'])): ?>
            <div class="<?= $_SESSION['alert'];?> mt-5 " role="alert">
                <?= $_SESSION['msg'];?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif;?>
        </div>
    

    
    <div class="row"> 
      <div class="col-12">
        <!-- <h2 style="background-color: purple;" class="text-white p-2 ">Add New Staff Member</h2> -->
        <div class="container mt-3">
        <form action="addstaff.php" method="post">
            <div class="row">
                <div class="col-md-6">
                <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name">
                </div>
                <div class="col-md-6">
                <input type="text" class="form-control" id="firstname" name="lastname" placeholder="Last name">
                </div>
                </div>
            <div class="row mt-3">
                <div class="col-md-4">
                <input type="text" class="form-control" name="username" placeholder="username">
                </div>
                <div class="col-md-4">
                <input type="text" class="form-control" name="password" placeholder="password">
                </div>
                <div class="col-md-4">
                <input type="text" class="form-control" name="confirm_password" placeholder="confirm password">
                </div>
            </div>
                <div class="row mt-3">
                <div class="col-md-6">
                <select class="form-control"  id="stdclass" name="staffclass">
                
                <?php 
                            $Query = "SELECT * FROM classes LIMIT 10";
                            $result = $link->query($Query);

                            while($row = $result->fetch_assoc()): ?>
                            <option value="<?= $row['classname']; ?>"><?= $row['classname']; ?></option>

                        <?php endwhile;?>
                
                </select>
                </div>
                <div class="col-md-6">
                <input type="text" class="form-control" id="stdAge" name="phonenumber" placeholder="Phone Number">
                </div>
                <input type="submit" class="btn btn-primary" value="Submit">
            </div>
            </div>
            </div>
</form>
      </div>
   
  <!-- dashboard content ends -->
  <?php require('footer.php');?>  

  
</body>

</html>

