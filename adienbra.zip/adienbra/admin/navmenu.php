<!-- navigation menu -->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<h6 style="color:#fff;"><a href="welcome.php">Adienbra M/A Primary School</a></h6>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-chart-bar" style="text-transform: uppercase;"></i> Dashboard</a>
          </li>
          <li class="nav-item">
            <a href="addstudent.php" class="nav-link">
              <i class="fas fa-list-ul"></i> Add Student</a>
          </li>
          <li class="nav-item">
            <a href="" class="nav-link">
            <i class="fas fa-network-wired"></i> Add Staff</a>
          </li>
          <li class="nav-item">
            <a href="" class="nav-link">
              <i class="fas fa-users"></i> Users</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
           <li class="nav-item">
            <div class="dropdown">
              <a href="" class="nav-link dropdown-toggle" data-toggle="dropdown" >
                <i class="fas fa-id-badge"></i> Tech Info</a>
              <div class="dropdown-menu">
                <a href="#" class="dropdown-item">Profile</a>
                <a href="#" class="dropdown-item">Settings</a>
                <a href="#" class="dropdown-item">Change Themes</a>
                <a href="#" class="dropdown-item">About us</a>
              </div>
            </div>
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">
              <i class="fas fa-sign-out-alt"></i> Logout</a>
          </li>
        </ul>
      </div>
    </nav>
  <!-- navigation menu ends here -->