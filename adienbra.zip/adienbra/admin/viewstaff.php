<?php


session_start();
require('config.php');

    if(isset($_POST['delete'])){
        $id = $_POST['delete'];

        $dQuery = "DELETE FROM staff WHERE id=?";
        $stmt = $link->prepare($dQuery);
        $stmt->bind_param("i",$id);

        if($stmt->execute()){
            $_SESSION['msg'] = "Deleted Successfully......";
            $_SESSION['alert'] = "alert alert-warning alert-dismissible fade show";
            header("location: viewstaff.php");
        }$stmt->close();
        $link->close();

    }
?>

<?php require('head.php');?>
  <!-- Start your project here-->
  <?php require('navmenu.php');?>
 
  <!-- dashboaRd contet start -->
  <div class="container-fluid">

        <?php if(isset($_SESSION['msg'])): ?>
            <div class="<?= $_SESSION['alert'];?> mt-5 " role="alert">
                <?= $_SESSION['msg'];
                  unset($_SESSION['msg']);?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif;?>
        </div>
    
    <div class="row"> 
      <div class="col-12">
        <h2 style="background-color: purple;" class="text-white p-2 ">All Staff Members</h2>
        <div class="container">
        <!-- creating table -->
        <table class="table mt-3">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Class</th>
              <th>Phone</th>
              <th>Username</th>
              <th>Created</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>

              <?php 
                $Query = "SELECT * FROM staff LIMIT 10";
                $result = $link->query($Query);

                while($row = $result->fetch_assoc()): ?>
            <tr style="text-transform: uppercase;">
              <td><?= $row['id']; ?></td>
              <td><?= $row['firstname']; ?></td>
              <td><?= $row['lastname']; ?></td>
              <td><?= $row['staffclass']; ?></td>
              <td><?= $row['phonenumber']; ?></td>
              <td><?= $row['username']; ?></td>
              <td><?= $row['created_at']; ?></td>
              <th>
              <form action="viewstaff.php" method="post">
              <button class="btn btn-danger" value="<?= $row['id']; ?>" name="delete">Delete</button>
              <button class="btn btn-primary" value="<?= $row['id']; ?>">Edit</button>

              </form>
                            </th>
            </tr>
            <?php endwhile;?>
            
            
          </tbody>
        </table>
      </div>
    </div>
    </div>
    </div>


    

  <!-- dashboard content ends -->
    <?php require('footer.php');?>  