<?php

?>

<?php require('config.php');?>
<?php require('head.php');?>
  <!-- Start your project here-->
  <?php require('navmenu.php');?>
  <?php require('topmenu.php');?>
  <!-- dashboaRd contet start -->
  <div class="container-fluid">
    
  <?php if(isset($_SESSION['msg'])): ?>
            <div class="<?= $_SESSION['alert'];?> mt-5 " role="alert">
                <?= $_SESSION['msg'];?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif;?>
        </div>
    

    <div class="row"> 
      <div class="col-8">
        <h2 style="background-color: purple;" class="text-white p-2 ">Latest Posts</h2>
        <div class="container">
        <!-- creating table -->
        <table class="table mt-3">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Class</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>

              <?php 
                $Query = "SELECT * FROM students LIMIT 10";
                $result = $link->query($Query);

                while($row = $result->fetch_assoc()): ?>
            <tr style="text-transform: uppercase;">
              <td><?= $row['id']; ?></td>
              <td><?= $row['firstname']; ?></td>
              <td><?= $row['lastname']; ?></td>
              <td><?= $row['stdclass']; ?></td>
              <td><?= $row['stdAge']; ?></td>
            </tr>
            <?php endwhile;?>
            
            
          </tbody>
        </table>
      </div>
    </div>


    <?php require('sidebar.php');?>  
  <!-- dashboard content ends -->
  <?php require('footer.php');?>  