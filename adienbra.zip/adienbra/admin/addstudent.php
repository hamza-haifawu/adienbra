<?php
    include("config.php");
    if(isset($_POST['add'])){
        $firstName = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $stdclass = $_POST['stdclass'];
        $stdAge = $_POST['stdAge'];

        //check if all fields are set
        if(!empty($firstName) && !empty($lastname) && !empty($stdclass) && !empty($stdAge)){
            //query to insert into database
            $sQuery = "INSERT INTO students(firstname,lastname,stdclass,stdAge) VALUES(?,?,?,?)";
            $stmt = $link->prepare($sQuery);
            $stmt->bind_param("ssss",$firstName,$lastname,$stdclass,$stdAge);
            if($stmt->execute()){
                header("location: welcome.php");
            }
        }else{
            echo "All fields are required";
        }


    }
?>


<?php require('head.php');?>
  <!-- Start your project here-->
  <?php require('navmenu.php');?>
  <?php require('topmenu.php');?>
  <!-- dashboaRd contet start -->
  <div class="container-fluid">
    
    <div class="row"> 
      <div class="col-12">
        <h2 style="background-color: purple;" class="text-white p-2 ">Add New Students</h2>
        <div class="container mt-3">
        <form <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" id="firstname" name="firstname" placeholder="First name">
    </div>
    <div class="col">
      <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Last name">
    </div>
</div>
    <div class="row mt-3">
    <!-- <div class="col">
      <input type="text" class="form-control" id="stdclass" name="stdclass" placeholder="Class">
    </div> -->
    <select class="form-control"  id="stdclass" name="stdclass">
    
    <?php 
                $Query = "SELECT * FROM classes LIMIT 10";
                $result = $link->query($Query);

                while($row = $result->fetch_assoc()): ?>
                 <option value="<?= $row['classname']; ?>"><?= $row['classname']; ?></option>

            <?php endwhile;?>
      
    </select>
    <div class="col">
      <input type="text" class="form-control" id="stdAge" name="stdAge" placeholder="Age">
    </div>
    <button class="btn btn-primary" name="add" onclick="verify()" type="submit">Submit</button>
  </div>
</form>
      </div>
   
  <!-- dashboard content ends -->
  <?php require('footer.php');?>  

  <script type="text/javascript">
   
  </script>
</body>

</html>

