<!-- navigation menu -->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
<h6 style="color:#fff;"><a href="welcome.php">Adienbra M/A Primary School</a></h6>
        <button class="navbar-toggler " data-toggle="collapse" data-target="#menu"> 
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="menu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a href="attendance.php" class="nav-link">
              <i class="fas fa-chart-bar" style="text-transform: uppercase;"></i> Attendance</a>
          </li>
          <li class="nav-item">
            <a href="viewstudents.php" class="nav-link">
              <i class="fas fa-list-ul"></i> View Student</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
           <li class="nav-item">
           
          </li>
          <li class="nav-item">
            <a href="logout.php" class="nav-link">
              <i class="fas fa-sign-out-alt"></i> Logout</a>
          </li>
        </ul>
      </div>
    </nav>
  <!-- navigation menu ends here -->