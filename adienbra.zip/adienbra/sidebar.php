
      <div class="col-md-4 mt-4">
          <div class="card">
            <div class=" bg-primary text-white p-4">
              <i class="fas fa-list-ul fa-6x"></i>
              <h2 class="float-right font-weight-bold" style="font-size: 50px; text-align: center;">
              <span class="d-block">
              <?php 
                                    
                $query = "SELECT * FROM students";
                $row = mysqli_query($link,$query);
                $number=mysqli_num_rows($row);
                echo $number;
                ;?> students
              </span></h2>
            </div>
            <div class="card-footer text-primary">
              <h6 class="text-center"><a href="viewstudents.php"> View All Students
              <i class="fas fa-arrow-alt-circle-right"></i>
                
              </h6></a>
            </div>
          </div>
          <div class="card mt-5">
            <div class=" bg-success text-white p-4 ">
              <i class="fas fa-list-ul fa-6x"></i>
              <h2 class="float-right font-weight-bold" style="font-size: 40px; text-align: center;">
              <?php 
                                    
                $query = "SELECT * FROM attendance";
                $row = mysqli_query($link,$query);
                $number=mysqli_num_rows($row);
                echo $number;
                ;?>
              <span class="d-block">Attendance</span></h2>
            </div>
            <div class="card-footer text-primary">
              <h6 class="text-center"><a href="attendance.php"> View attendance
              <i class="fas fa-arrow-alt-circle-right"></i></h6></a>
            </div>
          </div>
         
      </div> 
    </div>
